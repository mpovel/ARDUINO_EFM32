//AVR compatibility functions
#ifndef _DELAY_H_
#define _DELAY_H_

#define _delay_us(n) delayMicroseconds(n)

#define _delay_ms(n) delay(n)

#endif

