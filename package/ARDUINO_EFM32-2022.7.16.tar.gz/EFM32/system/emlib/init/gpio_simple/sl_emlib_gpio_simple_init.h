#ifndef SL_EMLIB_GPIO_SIMPLE_INIT_H
#define SL_EMLIB_GPIO_SIMPLE_INIT_H

/// Simple initialization function for GPIO
void sl_emlib_gpio_simple_init(void);

#endif // SL_EMLIB_GPIO_SIMPLE_INIT_H
